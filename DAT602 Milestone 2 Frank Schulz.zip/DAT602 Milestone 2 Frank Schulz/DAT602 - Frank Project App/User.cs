﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAT602___Frank_Project_App
{
    class User
    {
        public static User CurrentPlayer { get; set; }
        public string UserName;
        public int Grid;
        public int X;
        public int Y;
    }
}
